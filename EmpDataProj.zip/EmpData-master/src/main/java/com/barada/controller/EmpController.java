package com.barada.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.barada.domain.Emp;
import com.barada.service.EmpService;

@RestController
public class EmpController {
	@Autowired
	private EmpService service;
	
	@RequestMapping("/byId/{id}")
	public Emp getById(@PathVariable("id") int id) {
		System.out.println("hi"+" **"+"hello");
		return service.empById(id);
		
	}
	
	@RequestMapping("/allEmps")
	public List<Emp> getAllEmps(){
		System.out.println("EmpController.getAllEmps()");
		return service.empEmps();
	}
	
	@GetMapping("employees/test")
	public String test() {
		return "Anil";
	}

}
